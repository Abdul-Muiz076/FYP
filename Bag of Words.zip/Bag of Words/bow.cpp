#include <iostream>
#include <fstream>
#include <sstream>
#include <vector>
#include <string>
#include <cctype>
#include <algorithm>
#include <cstring>  // for strdup if needed
#include "text_preprocessing.h"

using namespace std;

struct Word {
    string word;
    int frequency;
};

// Add or update a word in the vocabulary list
int updateWordList(vector<Word> &words, const string &word) {
    for (int i = 0; i < words.size(); ++i) {
        if (words[i].word == word) {
            words[i].frequency++;
            return i;
        }
    }
    words.push_back({word, 1});
    return words.size() - 1;
}

// Tokenize sentence and update BoW vector
void processSentence(string sentence, vector<Word> &vocab, vector<int> &vector) {
    char word[100];
    int i = 0, w = 0;

    removeHTMLTags(sentence);
    removeURLs(sentence);
    removeAccents(sentence);

    while (i < sentence.length()) {
        if (isalpha(sentence[i])) {
            word[w++] = tolower(sentence[i]);
        } else {
            if (w > 1) {
                word[w] = '\0';
                string cleanWord(word);
                lemmatizeWord(cleanWord);
                if (!isStopWord(cleanWord)) {
                    int index = updateWordList(vocab, cleanWord);
                    if (index >= vector.size()) vector.resize(index + 1, 0);
                    vector[index] = 1;
                }
            }
            w = 0;
        }
        ++i;
    }

    if (w > 1) {
        word[w] = '\0';
        string cleanWord(word);
        lemmatizeWord(cleanWord);
        if (!isStopWord(cleanWord)) {
            int index = updateWordList(vocab, cleanWord);
            if (index >= vector.size()) vector.resize(index + 1, 0);
            vector[index] = 1;
        }
    }
}

// Save BoW model to CSV
void saveBoWModelToCSV(const vector<Word> &vocab, const string &filename) {
    ofstream fout(filename);
    if (!fout.is_open()) {
        perror("Failed to open BoW model CSV file");
        return;
    }

    fout << "Word,Frequency\n";
    for (const auto &entry : vocab) {
        fout << entry.word << "," << entry.frequency << "\n";
    }

    fout.close();
}

// Save BoW vectors to CSV
void saveBoWVectorsToCSV(const vector<vector<int>> &vectors, const vector<Word> &vocab, const string &filename) {
    ofstream fout(filename);
    if (!fout.is_open()) {
        perror("Failed to open BoW vector CSV file");
        return;
    }

    // Header row
    for (size_t j = 0; j < vocab.size(); ++j) {
        fout << vocab[j].word;
        if (j < vocab.size() - 1) fout << ",";
    }
    fout << "\n";

    // Vectors
    for (const auto &vec : vectors) {
        for (size_t j = 0; j < vocab.size(); ++j) {
            fout << (j < vec.size() ? vec[j] : 0);
            if (j < vocab.size() - 1) fout << ",";
        }
        fout << "\n";
    }

    fout.close();
}

int main() {
    string filename;
    cout << "Enter filename (with .txt extension): ";
    cin >> filename;

    ifstream fin(filename);
    if (!fin.is_open()) {
        perror("Error opening file");
        return 1;
    }

    vector<string> sentences;
    vector<Word> vocab;
    vector<vector<int>> BoWVectors;
    string line;

    while (getline(fin, line)) {
        sentences.push_back(line);
        BoWVectors.emplace_back(1000, 0); // Temporary size, will resize later
    }
    fin.close();

    for (size_t i = 0; i < sentences.size(); ++i) {
        string temp = sentences[i];
        processSentence(temp, vocab, BoWVectors[i]);
    }

    // Resize all BoW vectors to match final vocab size
    for (auto &vec : BoWVectors) {
        vec.resize(vocab.size(), 0);
    }

    // Print BoW model
    cout << "\nBag of Words Model:\n";
    for (const auto &entry : vocab) {
        cout << entry.word << ": " << entry.frequency << "\n";
    }

    // Print BoW vectors
    cout << "\nBoW Vectors:\n";
    for (size_t i = 0; i < BoWVectors.size(); ++i) {
        cout << "Sentence " << i + 1 << " BoW Vector: ";
        for (int val : BoWVectors[i]) {
            cout << val << " ";
        }
        cout << "\n";
    }

    // Save to files
    saveBoWModelToCSV(vocab, "bow_model.csv");
    saveBoWVectorsToCSV(BoWVectors, vocab, "bow_vectors.csv");

    return 0;
}
