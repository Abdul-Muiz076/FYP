#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <ctype.h>
#include "text_preprocessing.h"

#define MAX_LINE_LENGTH 1024

// Structure to hold a word and its frequency
typedef struct {
    char *word;
    int frequency;
} Word;

// Add or update a word in the word list
int updateWordList(Word **words, int *wordCount, const char *word) {
    for (int i = 0; i < *wordCount; i++) {
        if (strcmp((*words)[i].word, word) == 0) {
            (*words)[i].frequency++;
            return i;
        }
    }
    *words = realloc(*words, (*wordCount + 1) * sizeof(Word));
    (*words)[*wordCount].word = strdup(word);
    (*words)[*wordCount].frequency = 1;
    (*wordCount)++;
    return *wordCount - 1;
}

// Tokenize sentence and update word list (vocabulary)
void processSentence(char *sentence, Word **vocab, int *vocabSize, int *vector) {
    char word[100];
    int i = 0, w = 0;

    removeHTMLTags(sentence);
    removeURLs(sentence);
    removeAccents(sentence);

    while (sentence[i]) {
        if (isalpha(sentence[i])) {
            word[w++] = tolower(sentence[i]);
        } else {
            if (w > 1) {
                word[w] = '\0';
                lemmatizeWord(word);
                if (!isStopWord(word)) {
                    int index = updateWordList(vocab, vocabSize, word);
                    vector[index] = 1;
                }
            }
            w = 0;
        }
        i++;
    }

    // Final word (if any)
    if (w > 1) {
        word[w] = '\0';
        lemmatizeWord(word);
        if (!isStopWord(word)) {
            int index = updateWordList(vocab, vocabSize, word);
            vector[index] = 1;
        }
    }
}


int main() {
    char filename[100];
    printf("Enter filename (with .txt extension): ");
    scanf("%s", filename);

    FILE *fp = fopen(filename, "r");
    if (!fp) {
        perror("Error opening file");
        return 1;
    }

    char line[MAX_LINE_LENGTH];
    char **sentences = NULL;
    int sentenceCount = 0;

    Word *vocab = NULL;
    int vocabSize = 0;

    int **BoWVectors = NULL;

    // Read each line (sentence) from the file
    while (fgets(line, sizeof(line), fp)) {
        line[strcspn(line, "\n")] = '\0';
        
        sentences = realloc(sentences, (sentenceCount + 1) * sizeof(char *));
        sentences[sentenceCount] = strdup(line);

        BoWVectors = realloc(BoWVectors, (sentenceCount + 1) * sizeof(int *));
        BoWVectors[sentenceCount] = calloc(1000, sizeof(int)); // initial size, will fix later

        sentenceCount++;
    }
    fclose(fp);

    // Now process each sentence
    for (int i = 0; i < sentenceCount; i++) {
        char temp[MAX_LINE_LENGTH];
        strcpy(temp, sentences[i]); // preserve original
        processSentence(temp, &vocab, &vocabSize, BoWVectors[i]);
    }

    // Resize BoW vectors based on final vocabulary size
    for (int i = 0; i < sentenceCount; i++) {
        BoWVectors[i] = realloc(BoWVectors[i], vocabSize * sizeof(int));
    }

    // Print Bag of Words model
    printf("\nBag of Words Model:\n");
    for (int i = 0; i < vocabSize; i++) {
        printf("%s: %d\n", vocab[i].word, vocab[i].frequency);
    }

    // Print BoW Vectors
    printf("\nBoW Vectors:\n");
    for (int i = 0; i < sentenceCount; i++) {
        printf("Sentence %d BoW Vector: ", i + 1);
        for (int j = 0; j < vocabSize; j++) {
            printf("%d ", BoWVectors[i][j]);
        }
        printf("\n");
    }

    // Free memory
    for (int i = 0; i < vocabSize; i++) {
        free(vocab[i].word);
    }
    free(vocab);
    for (int i = 0; i < sentenceCount; i++) {
        free(sentences[i]);
        free(BoWVectors[i]);
    }
    free(sentences);
    free(BoWVectors);

    return 0;
}
