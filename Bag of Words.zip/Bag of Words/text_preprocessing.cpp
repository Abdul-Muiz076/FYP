#include <iostream>
#include <string>
#include <vector>
#include <cctype>
#include <cstring>
#include <locale>
#include <cwchar>
#include <cstdlib>
#include <sstream>
#include "text_preprocessing.h"

const std::vector<std::string> stopWords = {
    "the", "and", "a", "an", "is", "are", "was", "were", "to", "of",
    "in", "on", "for", "with", "at", "by", "from", "this", "that",
    "it", "as", "but", "they", "what", "we", "but", "should", "become", "how", "can", "so",
    "there", "will", "be", "such", "own", "all", "have", "has", "has", "you", "let",
    "where", "who", "our", "these", "do", "does", "those", "am"
};

void toLowerCase(std::string &str) {
    for (char &c : str) c = std::tolower(c);
}

bool isStopWord(const std::string &word) {
    for (const auto &stop : stopWords) {
        if (word == stop) return true;
    }
    return false;
}

void removePunctuation(std::string &word) {
    std::string clean;
    for (char c : word) {
        if (std::isalnum(static_cast<unsigned char>(c))) clean += c;
    }
    word = clean;
}

void removeHTMLTags(std::string &text) {
    bool inTag = false;
    std::string clean;
    for (char c : text) {
        if (c == '<') inTag = true;
        else if (c == '>') inTag = false;
        else if (!inTag) clean += c;
    }
    text = clean;
}

bool isURL(const std::string &word) {
    return word.find("http://") == 0 || word.find("https://") == 0 || word.find("www.") == 0;
}

void removeURLs(std::string &text) {
    std::stringstream ss(text);
    std::string token, result;
    while (ss >> token) {
        if (!isURL(token)) result += token + " ";
    }
    text = result;
}

void removeAccents(std::string &str) {
    setlocale(LC_ALL, "en_US.UTF-8");

    wchar_t accents[] = L"áàäãâéèëêíìïîóòöõôúùüûçñÁÀÄÃÂÉÈËÊÍÌÏÎÓÒÖÕÔÚÙÜÛÇÑśŚ";
    wchar_t replacements[] = L"aaaaaeeeeiiiiooooouuucnAAAAAEEEEIIIIOOOOOUUUUCNsS";

    wchar_t wstr[1024];
    mbstowcs(wstr, str.c_str(), sizeof(wstr) / sizeof(wstr[0]));

    for (int i = 0; wstr[i] != L'\0'; ++i) {
        wchar_t *pos = wcschr(accents, wstr[i]);
        if (pos) {
            int index = pos - accents;
            wstr[i] = replacements[index];
        }
    }

    char buffer[1024];
    wcstombs(buffer, wstr, sizeof(buffer));
    str = buffer;
}

void lemmatizeWord(std::string &word) {
    if (word == "running") word = "run";
    else if (word == "jumps") word = "jump";
    else if (word == "better") word = "good";
    else if (word == "cars") word = "car";
    else if (word == "wolves") word = "wolf";
    else if (word == "children") word = "child";
    else if (word == "geese") word = "goose";
    else if (word == "mice") word = "mouse";
    else if (word == "feet") word = "foot";

    int len = word.length();
    if (len > 3) {
        if (word[len - 1] == 's' && word != "this" && word != "was" && word != "has" &&
            word != "his" && word != "its" && word != "is") {
            word = word.substr(0, len - 1);
            len--;
        }

        if (len > 4 && word.substr(len - 3) == "ing") {
            word = word.substr(0, len - 3);
        } else if (len > 3 && word.substr(len - 2) == "ed") {
            word = word.substr(0, len - 2);
        }
    }
}
