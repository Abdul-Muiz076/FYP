#include <iostream>
#include <fstream>
#include <sstream>
#include <vector>
#include <string>
#include <cctype>
#include <algorithm>
#include <cstring>
#include <unordered_map> // Include for hash tables
#include "text_preprocessing.h" // Assuming this remains unchanged

using namespace std;

// --- Data Structures ---
// We still need an ordered list of words for consistent vector indexing
// and CSV header output.
vector<string> orderedVocab;
// Map word to its frequency
unordered_map<string, int> vocabFrequency;
// Map word to its index in orderedVocab for quick lookup
unordered_map<string, int> wordToIndex;

// Use a sparse representation for BoW Vectors: vector of maps
// Each map stores {word_index: count} for words present in the sentence
// Here, count will always be 1 as per the original logic.
vector<unordered_map<int, int>> sparseBoWVectors;


// --- Functions ---

// Add or update a word in the vocabulary structures
// Returns the index of the word in the orderedVocab
int updateWordList(const string &word) {
    // Check if word exists using the wordToIndex map (O(1) average)
    auto it = wordToIndex.find(word);
    if (it != wordToIndex.end()) {
        // Word exists, increment frequency
        vocabFrequency[word]++;
        return it->second; // Return existing index
    } else {
        // Word is new
        int newIndex = orderedVocab.size(); // Index will be the current size
        orderedVocab.push_back(word);      // Add to ordered list
        wordToIndex[word] = newIndex;      // Add to index map
        vocabFrequency[word] = 1;          // Set initial frequency
        return newIndex;                   // Return the new index
    }
}

// Tokenize sentence and update sparse BoW vector
void processSentence(string sentence, unordered_map<int, int> &sentenceVector) {
    char wordBuffer[100]; // Renamed from 'word' to avoid conflict with string variable
    int i = 0, w = 0;

    // --- Preprocessing ---
    // It's generally better to preprocess the whole sentence string first
    removeHTMLTags(sentence);
    removeURLs(sentence);
    removeAccents(sentence);
    // Lowercase is handled char by char below, but could be done here too:
    // transform(sentence.begin(), sentence.end(), sentence.begin(), ::tolower);

    while (i < sentence.length()) {
        // Using isalpha to mimic original logic
        if (isalpha(static_cast<unsigned char>(sentence[i]))) {
             // Prevent buffer overflow
            if (w < sizeof(wordBuffer) - 1) {
                 wordBuffer[w++] = tolower(static_cast<unsigned char>(sentence[i]));
            }
        } else {
            // Potential word boundary
            if (w > 1) { // Only process if word length > 1
                wordBuffer[w] = '\0';       // Null-terminate C-style string
                string currentWord(wordBuffer); // Convert to std::string

                lemmatizeWord(currentWord); // Apply lemmatization

                if (!isStopWord(currentWord)) {
                    int index = updateWordList(currentWord); // Update global vocab & get index
                    // Add word index to the sparse vector for this sentence
                    sentenceVector[index] = 1; // Using map assigns/updates the value
                }
            }
            w = 0; // Reset word buffer index
        }
        ++i;
    }

    // Handle potential word at the end of the sentence
    if (w > 1) {
        wordBuffer[w] = '\0';
        string currentWord(wordBuffer);
        lemmatizeWord(currentWord);
        if (!isStopWord(currentWord)) {
            int index = updateWordList(currentWord);
            sentenceVector[index] = 1;
        }
    }
}

// Save BoW model (vocabulary and frequencies) to CSV
void saveBoWModelToCSV(const string &filename) {
    ofstream fout(filename);
    if (!fout.is_open()) {
        perror(("Failed to open BoW model CSV file: " + filename).c_str());
        return;
    }

    fout << "Word,Frequency\n";
    // Iterate through the ordered vocabulary list to maintain order
    for (const auto &word : orderedVocab) {
        // Look up frequency in the map (use .at() or check with find)
        // Using find is safer in case of inconsistencies, though shouldn't happen here.
        auto freqIt = vocabFrequency.find(word);
        if (freqIt != vocabFrequency.end()) {
             fout << word << "," << freqIt->second << "\n";
        } else {
             // Should not happen with current logic, but good practice
             cerr << "Warning: Word '" << word << "' found in orderedVocab but not in vocabFrequency map." << endl;
             fout << word << ",0\n"; // Or handle error differently
        }
    }

    fout.close();
    cout << "BoW model saved to " << filename << endl;
}

// Save BoW vectors (dense representation) to CSV from sparse data
void saveBoWVectorsToCSV(const string &filename) {
    ofstream fout(filename);
    if (!fout.is_open()) {
        perror(("Failed to open BoW vector CSV file: " + filename).c_str());
        return;
    }

    // Header row (using the ordered vocabulary)
    for (size_t j = 0; j < orderedVocab.size(); ++j) {
        fout << orderedVocab[j];
        if (j < orderedVocab.size() - 1) fout << ",";
    }
    fout << "\n";

    // Vectors (reconstructing dense from sparse)
    size_t vocabSize = orderedVocab.size();
    for (const auto &sparseVec : sparseBoWVectors) {
        for (size_t j = 0; j < vocabSize; ++j) {
            // Check if the word index 'j' exists in the current sentence's sparse map
            if (sparseVec.count(j)) { // O(1) average lookup
                fout << sparseVec.at(j); // Write the stored value (which is 1 here)
            } else {
                fout << 0; // Word not present
            }
            if (j < vocabSize - 1) fout << ",";
        }
        fout << "\n";
    }

    fout.close();
    cout << "BoW vectors saved to " << filename << endl;
}

int main() {
    string inputFilename;
    cout << "Enter filename (with .txt extension): ";
    cin >> inputFilename;

    ifstream fin(inputFilename);
    if (!fin.is_open()) {
        perror(("Error opening file: " + inputFilename).c_str());
        return 1;
    }

    vector<string> sentences;
    string line;

    // Read sentences
    while (getline(fin, line)) {
         if (!line.empty()) { // Avoid processing empty lines
             sentences.push_back(line);
             // Add an empty map for this sentence's sparse vector
             sparseBoWVectors.emplace_back();
         }
    }
    fin.close();

    if (sentences.empty()) {
        cout << "Input file is empty or contains no valid lines." << endl;
        return 0;
    }


    // Process each sentence and populate the corresponding sparse vector
    for (size_t i = 0; i < sentences.size(); ++i) {
        // Pass the specific sparse vector map for this sentence
        processSentence(sentences[i], sparseBoWVectors[i]);
    }


    // --- Print BoW Model ---
    cout << "\nBag of Words Model:\n";
    // Iterate through orderedVocab to print in the order words were encountered
    for (const auto &word : orderedVocab) {
         // Safely access frequency
         auto freqIt = vocabFrequency.find(word);
         int frequency = (freqIt != vocabFrequency.end()) ? freqIt->second : 0;
         cout << word << ": " << frequency << "\n";
    }


    // --- Print BoW Vectors (reconstructing dense view for clarity) ---
    cout << "\nBoW Vectors:\n";
    size_t vocabSize = orderedVocab.size();
    for (size_t i = 0; i < sparseBoWVectors.size(); ++i) {
        cout << "Sentence " << i + 1 << " BoW Vector: ";
        const auto& sparseVec = sparseBoWVectors[i];
        for (size_t j = 0; j < vocabSize; ++j) {
            // Check if index j is present in the sparse map for sentence i
            if (sparseVec.count(j)) {
                cout << sparseVec.at(j) << " "; // Should be 1
            } else {
                cout << 0 << " ";
            }
        }
        cout << "\n";
    }

    // --- Save to Files ---
    saveBoWModelToCSV("bow_model.csv");
    saveBoWVectorsToCSV("bow_vectors.csv");

    return 0;
}