#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <ctype.h>
#include "text_preprocessing.h"



// Structure to store words and their frequency
typedef struct {
    char *word;  // Dynamic word length
    int count;
} WordFreq;


// Function to check if a word exists in the array
int findWord(WordFreq words[], int size, char *word) {
    for (int i = 0; i < size; i++) {
        if (strcmp(words[i].word, word) == 0) {
            return i;  // Return index if word exists
        }
    }
    return -1;  // Return -1 if word is new
}

// Function to add a word to the dynamic Bag of Words
void addWord(WordFreq **words, int *size, int *capacity, const char *word) {
    // Check if resizing is needed
    if (*size >= *capacity) {
        *capacity *= 2;
        *words = realloc(*words, (*capacity) * sizeof(WordFreq));
        if (*words == NULL) {
            printf("Memory allocation failed.\n");
            exit(1);
        }
    }

    // Find the word in the existing list
    for (int i = 0; i < *size; i++) {
        if (strcmp((*words)[i].word, word) == 0) {
            (*words)[i].count++;
            return;
        }
    }

    // Add a new word if not found
    (*words)[*size].word = malloc(strlen(word) + 1);  // Allocate memory for the word
    if ((*words)[*size].word == NULL) {
        printf("Memory allocation failed.\n");
        exit(1);
    }
    strcpy((*words)[*size].word, word);
    (*words)[*size].count = 1;
    (*size)++;
}


// Function to process text and build the dynamic BoW
void processText(char *text, WordFreq **words, int *size, int *capacity) {
    removeHTMLTags(text);  // Remove HTML tags first
    removeURLs(text);      // Remove URLs
    removeAccents(text);

    char *token = strtok(text, " ,.?!\n");  // Tokenize text
    while (token != NULL) {
        toLowerCase(token);
        removePunctuation(token);
        lemmatizeWord(token);
        if (!isStopWord(token) && isalpha(token[0]) && strlen(token) > 1) {
            addWord(words, size, capacity, token);
        }
        token = strtok(NULL, " ,.?!\n");
    }
}

// Function to dynamically read the entire file into a buffer
char* readFile(const char *filename) {
    FILE *file = fopen(filename, "r");
    if (file == NULL) {
        printf("Error opening file.\n");
        exit(1);
    }

    char *buffer = NULL;
    size_t bufferSize = 0;
    size_t chunkSize = 1024;  // Read in chunks of 1024 bytes

    // Allocate the initial chunk
    buffer = malloc(chunkSize);
    if (buffer == NULL) {
        printf("Memory allocation failed.\n");
        exit(1);
    }

    size_t totalSize = 0;
    size_t bytesRead;

    // Read the file in chunks
    while ((bytesRead = fread(buffer + totalSize, 1, chunkSize, file)) > 0) {
        totalSize += bytesRead;

        // Resize the buffer if needed
        if (bytesRead == chunkSize) {
            chunkSize *= 2;
            buffer = realloc(buffer, totalSize + chunkSize);
            if (buffer == NULL) {
                printf("Memory allocation failed.\n");
                exit(1);
            }
        }
    }

    // Null-terminate the buffer
    buffer[totalSize] = '\0';
    fclose(file);

    return buffer;
}


// Main function
int main() {
    int size = 0;          // Number of unique words
    int capacity = 10;     // Initial capacity for words array

    // Dynamically allocate the words array
    WordFreq *words = malloc(capacity * sizeof(WordFreq));
    if (words == NULL) {
        printf("Memory allocation failed.\n");
        return 1;
    }

    // Read the entire file dynamically
    char *text = readFile("input.txt");

    // Process the text and build the BoW
    processText(text, &words, &size, &capacity);

    // Display the Bag of Words (word-frequency pairs)
    printf("BoW Vector Format:\n[");
    for (int i = 0; i < size; i++) {
        printf("%d", words[i].count);
        if (i < size - 1) printf(", ");  // Add comma for separation
    }
    printf("]\n");
    

    // Clean up dynamically allocated memory
    free(words);
    free(text);

    return 0;
}
