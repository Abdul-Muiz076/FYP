import re
import unicodedata
import csv
import string # Used implicitly if replicating isalnum/isalpha logic exactly
from collections import defaultdict

# --- Text Preprocessing Functions ---

# Replicate the stop words list from C++
stop_words = {
    "the", "and", "a", "an", "is", "are", "was", "were", "to", "of",
    "in", "on", "for", "with", "at", "by", "from", "this", "that",
    "it", "as", "but", "they", "what", "we", "should", "become", "how", "can", "so",
    "there", "will", "be", "such", "own", "all", "have", "has", "you", "let",
    "where", "who", "our", "these", "do", "does", "those", "am"
}

def remove_html_tags(text):
    """Removes HTML tags from a string."""
    clean = re.compile('<.*?>')
    return re.sub(clean, '', text)

def remove_urls(text):
    """Removes URLs (starting with http, https, or www.) from a string."""
    # Remove http/https links
    text = re.sub(r'https?://\S+', '', text)
    # Remove www links (simplified)
    text = re.sub(r'www\.\S+', '', text)
    # Clean up potential extra whitespace left behind
    text = re.sub(r'\s+', ' ', text).strip()
    return text

def remove_accents(text):
    """Removes accents from characters in a string."""
    try:
        # Normalize to decomposed form (NFD), then filter out non-spacing marks
        nfkd_form = unicodedata.normalize('NFD', text)
        return "".join([c for c in nfkd_form if not unicodedata.combining(c)])
    except TypeError:
        # Handle potential issues if input isn't a string
        return text

def lemmatize_word(word):
    """Performs basic rule-based lemmatization similar to the C++ version."""
    # Specific irregulars first
    if word == "running": return "run"
    if word == "jumps": return "jump"
    if word == "better": return "good"
    if word == "cars": return "car"
    if word == "wolves": return "wolf"
    if word == "children": return "child"
    if word == "geese": return "goose"
    if word == "mice": return "mouse"
    if word == "feet": return "foot"

    # Basic suffix removal (plural 's', 'ing', 'ed')
    # Ensure it doesn't incorrectly strip words like 'is', 'was', 'has' etc.
    if len(word) > 3 and word.endswith('s') and word not in {"is", "was", "has", "his", "its", "this", "does", "geese", "mice"}:
        word = word[:-1]
    elif len(word) > 4 and word.endswith('ing'):
        # Basic check: potentially add 'e' back? Or leave as is like C++?
        # Let's stick to simple removal like C++ for now.
        word = word[:-3]
    elif len(word) > 3 and word.endswith('ed'):
        # Basic check: potentially add 'e' back? Or leave as is?
        word = word[:-2]

    return word

def is_stop_word(word):
    """Checks if a word is in the stop word list."""
    return word in stop_words

# --- BoW Core Logic ---

def update_word_list(vocab_list, vocab_freq, word_to_index, word):
    """Adds or updates a word in the vocabulary structures."""
    if word not in word_to_index:
        index = len(vocab_list)
        word_to_index[word] = index
        vocab_list.append(word)
        vocab_freq[word] = 1
    else:
        index = word_to_index[word]
        vocab_freq[word] += 1
    return index

def process_sentence(sentence, vocab_list, vocab_freq, word_to_index):
    """
    Processes a sentence: preprocesses, tokenizes, updates vocabulary,
    and returns a set of vocabulary indices present in the sentence.
    """
    # 1. Preprocessing steps
    sentence = remove_html_tags(sentence)
    sentence = remove_urls(sentence)
    sentence = remove_accents(sentence)
    sentence = sentence.lower() # Convert to lowercase before tokenization

    sentence_indices = set() # Store indices for *this* sentence's vector

    # 2. Tokenization and word processing (mimicking C++ char-by-char logic)
    current_word = ""
    for char in sentence:
        if char.isalpha():
            current_word += char
        else:
            # End of a potential word
            if len(current_word) > 1: # Check length (w > 1 in C++)
                clean_word = lemmatize_word(current_word)
                if not is_stop_word(clean_word):
                    index = update_word_list(vocab_list, vocab_freq, word_to_index, clean_word)
                    sentence_indices.add(index) # Mark presence for this sentence
            current_word = "" # Reset for next word

    # Handle potential word at the end of the sentence
    if len(current_word) > 1:
        clean_word = lemmatize_word(current_word)
        if not is_stop_word(clean_word):
            index = update_word_list(vocab_list, vocab_freq, word_to_index, clean_word)
            sentence_indices.add(index)

    return sentence_indices

# --- CSV Saving Functions ---

def save_bow_model_to_csv(vocab_list, vocab_freq, filename="bow_model.csv"):
    """Saves the vocabulary and frequencies to a CSV file."""
    try:
        with open(filename, 'w', newline='', encoding='utf-8') as fout:
            writer = csv.writer(fout)
            writer.writerow(["Word", "Frequency"]) # Header
            for word in vocab_list:
                writer.writerow([word, vocab_freq.get(word, 0)]) # Use vocab_list to maintain order
        print(f"BoW model saved to {filename}")
    except IOError as e:
        print(f"Error: Failed to open or write BoW model CSV file: {e}")
    except Exception as e:
        print(f"An unexpected error occurred while saving BoW model: {e}")


def save_bow_vectors_to_csv(bow_vectors, vocab_list, filename="bow_vectors.csv"):
    """Saves the BoW vectors to a CSV file."""
    try:
        with open(filename, 'w', newline='', encoding='utf-8') as fout:
            writer = csv.writer(fout)
            # Header row (vocabulary words)
            writer.writerow(vocab_list)
            # Vector rows
            writer.writerows(bow_vectors)
        print(f"BoW vectors saved to {filename}")
    except IOError as e:
        print(f"Error: Failed to open or write BoW vector CSV file: {e}")
    except Exception as e:
        print(f"An unexpected error occurred while saving BoW vectors: {e}")


# --- Main Execution ---

if __name__ == "__main__":
    filename = input("Enter filename (with .txt extension): ")

    sentences = []
    try:
        with open(filename, 'r', encoding='utf-8') as fin:
            sentences = [line.strip() for line in fin if line.strip()] # Read non-empty lines
    except FileNotFoundError:
        print(f"Error: File '{filename}' not found.")
        exit(1)
    except IOError as e:
        print(f"Error reading file '{filename}': {e}")
        exit(1)

    if not sentences:
        print("Input file is empty or contains no valid lines.")
        exit(0)

    # Vocabulary Structures
    vocab_list = [] # Stores unique words in order of appearance
    vocab_freq = defaultdict(int) # Stores frequency of each word {word: count}
    word_to_index = {} # Maps word to its index in vocab_list {word: index}

    # Store sparse representation first (indices present in each sentence)
    bow_vectors_sparse = []

    # Process each sentence
    for sentence in sentences:
        present_indices = process_sentence(sentence, vocab_list, vocab_freq, word_to_index)
        bow_vectors_sparse.append(present_indices)

    # --- Create Dense BoW Vectors ---
    vocab_size = len(vocab_list)
    bow_vectors_dense = []
    for indices_set in bow_vectors_sparse:
        vector = [0] * vocab_size
        for index in indices_set:
            if 0 <= index < vocab_size: # Safety check
                 vector[index] = 1
        bow_vectors_dense.append(vector)


    # --- Print BoW Model (Vocabulary) ---
    print("\nBag of Words Model:")
    # Sort by appearance order (using vocab_list) or alphabetically?
    # C++ printed in appearance order. Let's stick to that using vocab_list.
    for word in vocab_list:
         print(f"{word}: {vocab_freq[word]}")
    # Alternative: print alphabetically sorted
    # for word, freq in sorted(vocab_freq.items()):
    #     print(f"{word}: {freq}")


    # --- Print BoW Vectors ---
    print("\nBoW Vectors:")
    for i, vec in enumerate(bow_vectors_dense):
        # Use len(vec) which should match vocab_size
        print(f"Sentence {i + 1} BoW Vector: {' '.join(map(str, vec))}")

    # --- Save to Files ---
    save_bow_model_to_csv(vocab_list, vocab_freq, "bow_model.csv")
    save_bow_vectors_to_csv(bow_vectors_dense, vocab_list, "bow_vectors.csv")