#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <ctype.h>
#include "text_preprocessing.h"

#define MAX_LINE_LENGTH 1024

// Structure to hold a word and its frequency
typedef struct {
    char *word;
    int frequency;
} Word;

// Add or update a word in the word list
int updateWordList(Word **words, int *wordCount, const char *word) {
    for (int i = 0; i < *wordCount; i++) {
        if (strcmp((*words)[i].word, word) == 0) {
            (*words)[i].frequency++;
            return i;
        }
    }
    *words = realloc(*words, (*wordCount + 1) * sizeof(Word));
    (*words)[*wordCount].word = strdup(word);
    (*words)[*wordCount].frequency = 1;
    (*wordCount)++;
    return *wordCount - 1;
}

// Tokenize sentence and update word list (vocabulary)
void processSentence(char *sentence, Word **vocab, int *vocabSize, int *vector) {
    char word[100];
    int i = 0, w = 0;

    removeHTMLTags(sentence);
    removeURLs(sentence);
    removeAccents(sentence);

    while (sentence[i]) {
        if (isalpha(sentence[i])) {
            word[w++] = tolower(sentence[i]);
        } else {
            if (w > 1) {
                word[w] = '\0';
                lemmatizeWord(word);
                if (!isStopWord(word)) {
                    int index = updateWordList(vocab, vocabSize, word);
                    vector[index] = 1;
                }
            }
            w = 0;
        }
        i++;
    }

    // Final word (if any)
    if (w > 1) {
        word[w] = '\0';
        lemmatizeWord(word);
        if (!isStopWord(word)) {
            int index = updateWordList(vocab, vocabSize, word);
            vector[index] = 1;
        }
    }
}

// Save BoW Model (vocabulary and word frequencies) to CSV
void saveBoWModelToCSV(const Word *vocab, int vocabSize, const char *filename) {
    FILE *fp = fopen(filename, "w");
    if (!fp) {
        perror("Failed to open BoW model CSV file");
        return;
    }

    fprintf(fp, "Word,Frequency\n");
    for (int i = 0; i < vocabSize; i++) {
        fprintf(fp, "%s,%d\n", vocab[i].word, vocab[i].frequency);
    }

    fclose(fp);
}

// Save BoW Vectors (for each sentence) to CSV
void saveBoWVectorsToCSV(int **vectors, int sentenceCount, int vocabSize, Word *vocab, const char *filename) {
    FILE *fp = fopen(filename, "w");
    if (!fp) {
        perror("Failed to open BoW vector CSV file");
        return;
    }

    // Header row with words
    for (int j = 0; j < vocabSize; j++) {
        fprintf(fp, "%s", vocab[j].word);
        if (j < vocabSize - 1) fprintf(fp, ",");
    }
    fprintf(fp, "\n");

    // Vector rows
    for (int i = 0; i < sentenceCount; i++) {
        for (int j = 0; j < vocabSize; j++) {
            fprintf(fp, "%d", vectors[i][j]);
            if (j < vocabSize - 1) fprintf(fp, ",");
        }
        fprintf(fp, "\n");
    }

    fclose(fp);
}

int main() {
    char filename[100];
    printf("Enter filename (with .txt extension): ");
    scanf("%s", filename);

    FILE *fp = fopen(filename, "r");
    if (!fp) {
        perror("Error opening file");
        return 1;
    }

    char line[MAX_LINE_LENGTH];
    char **sentences = NULL;
    int sentenceCount = 0;

    Word *vocab = NULL;
    int vocabSize = 0;

    int **BoWVectors = NULL;

    // Read each line (sentence) from the file
    while (fgets(line, sizeof(line), fp)) {
        line[strcspn(line, "\n")] = '\0';
        
        sentences = realloc(sentences, (sentenceCount + 1) * sizeof(char *));
        sentences[sentenceCount] = strdup(line);

        BoWVectors = realloc(BoWVectors, (sentenceCount + 1) * sizeof(int *));
        BoWVectors[sentenceCount] = calloc(1000, sizeof(int)); // initial size, will fix later

        sentenceCount++;
    }
    fclose(fp);

    // Now process each sentence
    for (int i = 0; i < sentenceCount; i++) {
        char temp[MAX_LINE_LENGTH];
        strcpy(temp, sentences[i]); // preserve original
        processSentence(temp, &vocab, &vocabSize, BoWVectors[i]);
    }

    // Resize BoW vectors based on final vocabulary size
    for (int i = 0; i < sentenceCount; i++) {
        BoWVectors[i] = realloc(BoWVectors[i], vocabSize * sizeof(int));
    }

    // Print Bag of Words model
    printf("\nBag of Words Model:\n");
    for (int i = 0; i < vocabSize; i++) {
        printf("%s: %d\n", vocab[i].word, vocab[i].frequency);
    }

    // Print BoW Vectors
    printf("\nBoW Vectors:\n");
    for (int i = 0; i < sentenceCount; i++) {
        printf("Sentence %d BoW Vector: ", i + 1);
        for (int j = 0; j < vocabSize; j++) {
            printf("%d ", BoWVectors[i][j]);
        }
        printf("\n");
    }

    // Save the BoW model and vectors to CSV files
    saveBoWModelToCSV(vocab, vocabSize, "bow_model.csv");
    saveBoWVectorsToCSV(BoWVectors, sentenceCount, vocabSize, vocab, "bow_vectors.csv");

    // Free memory
    for (int i = 0; i < vocabSize; i++) {
        free(vocab[i].word);
    }
    free(vocab);
    for (int i = 0; i < sentenceCount; i++) {
        free(sentences[i]);
        free(BoWVectors[i]);
    }
    free(sentences);
    free(BoWVectors);

    return 0;
}
preprocessing.......................................
...........................................
........................................
....................................
...................................
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <ctype.h>
#include <stdbool.h>
#include "text_preprocessing.h"
#include <locale.h>
#include <wchar.h>

// List of stop words
const char *stopWords[] = {
    "the", "and", "a", "an", "is", "are", "was", "were", "to", "of", 
    "in", "on", "for", "with", "at", "by", "from", "this", "that", 
    "it", "as", "but", "they", "what", "we", "but", "should", "become", "how", "can", "so" 
    ,"there", "will", "be", "such", "own", "all", "have", "has", "has", "you", "let", 
    "where", "who", "our", "these", "do", "does", "those","am",
};
const int stopWordsCount = sizeof(stopWords) / sizeof(stopWords[0]);

// Function to convert text to lowercase
void toLowerCase(char *str) {
    for (int i = 0; str[i]; i++) {
        str[i] = tolower(str[i]);
    }
}

// Function to check if a word is a stop word
int isStopWord(const char *word) {
    for (int i = 0; i < stopWordsCount; i++) {
        if (strcmp(word, stopWords[i]) == 0) {
            return 1; // It is a stop word
        }
    }
    return 0; // It is not a stop word
}
// Function to remove all punctuation from a word
void removePunctuation(char *word) {
    int i, j = 0;
    char cleanWord[strlen(word) + 1]; // Temporary storage

    for (i = 0; word[i] != '\0'; i++) {
        if (isalnum(word[i])) { // Keep only letters and numbers
            cleanWord[j++] = word[i];
        }
    }
    cleanWord[j] = '\0'; // Null-terminate the cleaned word
    strcpy(word, cleanWord); // Copy cleaned word back to original
}

// Function to remove HTML tags from text
void removeHTMLTags(char *text) {
    int inTag = 0;  // Flag to check if inside <tag>
    int i, j = 0;
    char cleanText[strlen(text) + 1]; // Temporary storage

    for (i = 0; text[i] != '\0'; i++) {
        if (text[i] == '<') {
            inTag = 1; // Start of HTML tag
        } else if (text[i] == '>') {
            inTag = 0; // End of HTML tag
        } else if (!inTag) {
            cleanText[j++] = text[i]; // Copy only non-tag characters
        }
    }
    cleanText[j] = '\0'; // Null-terminate the cleaned text
    strcpy(text, cleanText); // Copy cleaned text back
}

// Function to check if a word is a URL
bool isURL(const char *word) {
    return (strstr(word, "http://") == word || 
            strstr(word, "https://") == word || 
            strstr(word, "www.") == word);
}

// Function to remove URLs from text
void removeURLs(char *text) {
    char *token, *cleanText;
    cleanText = (char *)malloc(strlen(text) + 1);
    cleanText[0] = '\0';

    token = strtok(text, " \n"); // Tokenize based on space
    while (token != NULL) {
        if (!isURL(token)) { // Only keep non-URL words
            strcat(cleanText, token);
            strcat(cleanText, " "); // Add space between words
        }
        token = strtok(NULL, " \n");
    }

    strcpy(text, cleanText); // Copy cleaned text back
    free(cleanText); // Free allocated memory
}

// Function to remove accents from characters
#include <stdio.h>
#include <string.h>

// Function to remove accents from wide-character strings
void removeAccents(char *str) {
    // Set locale for UTF-8
    setlocale(LC_ALL, "en_US.UTF-8");

    wchar_t accents[] = L"áàäãâéèëêíìïîóòöõôúùüûçñÁÀÄÃÂÉÈËÊÍÌÏÎÓÒÖÕÔÚÙÜÛÇÑśŚ";
    wchar_t replacements[] = L"aaaaaeeeeiiiiooooouuucnAAAAAEEEEIIIIOOOOOUUUUCNsS";

    wchar_t wstr[1024];
    mbstowcs(wstr, str, sizeof(wstr) / sizeof(wstr[0]));  // Convert to wide string

    for (int i = 0; wstr[i] != L'\0'; i++) {
        wchar_t *accent_pos = wcschr(accents, wstr[i]);
        if (accent_pos) {
            int index = accent_pos - accents;
            wstr[i] = replacements[index];
        }
    }

    wcstombs(str, wstr, 1024);  // Convert back to multibyte string
}
// Function to apply basic lemmatization rules
void lemmatizeWord(char *word) {
    // Common suffix replacements
    if (strcmp(word, "running") == 0) strcpy(word, "run");
    else if (strcmp(word, "jumps") == 0) strcpy(word, "jump");
    else if (strcmp(word, "better") == 0) strcpy(word, "good");
    else if (strcmp(word, "cars") == 0) strcpy(word, "car");
    else if (strcmp(word, "wolves") == 0) strcpy(word, "wolf");
    else if (strcmp(word, "children") == 0) strcpy(word, "child");
    else if (strcmp(word, "geese") == 0) strcpy(word, "goose");
    else if (strcmp(word, "mice") == 0) strcpy(word, "mouse");
    else if (strcmp(word, "feet") == 0) strcpy(word, "foot");

    // Rule-based handling for plurals
    int len = strlen(word);
    if (len > 3) {
        // Smart plural 's' removal with exceptions
        if (word[len - 1] == 's' &&
            strcmp(word, "this") != 0 &&
            strcmp(word, "was") != 0 &&
            strcmp(word, "has") != 0 &&
            strcmp(word, "his") != 0 &&
            strcmp(word, "its") != 0 &&
            strcmp(word, "is") != 0) {
            word[len - 1] = '\0';
            len--;
        }
    
        // Handle common suffixes after updating len
        if (len > 4 && strcmp(&word[len - 3], "ing") == 0) {
            word[len - 3] = '\0'; // Remove 'ing'
        } else if (len > 3 && strcmp(&word[len - 2], "ed") == 0) {
            word[len - 2] = '\0'; // Remove 'ed'
        }
    }
}
header.......................................
...........................................
........................................
....................................
...................................
#ifndef TEXT_PREPROCESSING_H
#define TEXT_PREPROCESSING_H

void toLowerCase(char *str);
int isStopWord(const char *word);  // 🔹 Add this declaration
void removePunctuation(char *word);
void removeHTMLTags(char *text);
void removeURLs(char *text);
void removeAccents(char *str);
void lemmatizeWord(char *word);


#endif
