#ifndef TEXT_PREPROCESSING_H
#define TEXT_PREPROCESSING_H

void toLowerCase(std::string &str);
bool isStopWord(const std::string &word);  // 🔹 Add this declaration
void removePunctuation(std::string &word);
void removeHTMLTags(std::string &text);
void removeURLs(std::string &text);
void removeAccents(std::string &str);
void lemmatizeWord(std::string &word);


#endif
