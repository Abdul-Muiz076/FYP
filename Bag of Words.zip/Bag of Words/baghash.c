#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <ctype.h>

#define HASH_SIZE 1000   // Size of hash table
#define MAX_WORD_LEN 50  // Maximum word length

// Structure for a node in the hash table (linked list)
typedef struct Node {
    char word[MAX_WORD_LEN];
    int count;
    struct Node* next;
} Node;

// Hash table array (array of pointers to linked lists)
Node* hashTable[HASH_SIZE];

// Hash function to compute index
unsigned int hashFunction(const char* str) {
    unsigned int hash = 0;
    while (*str) {
        hash = (hash * 31) + *str;  // Simple hash function
        str++;
    }
    return hash % HASH_SIZE;  // Index within table size
}

// Convert string to lowercase
void toLowerCase(char *str) {
    for (int i = 0; str[i]; i++) {
        str[i] = tolower(str[i]);
    }
}

// Insert a word into the hash table
void insertWord(const char* word) {
    unsigned int index = hashFunction(word);

    // Check if word already exists in the linked list at this index
    Node* current = hashTable[index];
    while (current) {
        if (strcmp(current->word, word) == 0) {
            current->count++;  // Increase count if found
            return;
        }
        current = current->next;
    }

    // If not found, create a new node and insert at the beginning
    Node* newNode = (Node*)malloc(sizeof(Node));
    strcpy(newNode->word, word);
    newNode->count = 1;
    newNode->next = hashTable[index];  // Insert at head
    hashTable[index] = newNode;
}

// Process text and tokenize words
void processText(char* text) {
    char* token = strtok(text, " ,.?!\n");  // Tokenize text
    while (token != NULL) {
        toLowerCase(token);  // Convert word to lowercase
        if (strlen(token) > 1) {  // Ignore single characters (except 'a', 'I')
            insertWord(token);
        }
        token = strtok(NULL, " ,.?!\n");
    }
}

// Read input file
void readFile(char* filename, char* buffer, int bufferSize) {
    FILE* file = fopen(filename, "r");
    if (file == NULL) {
        printf("Error opening file.\n");
        exit(1);
    }
    fread(buffer, 1, bufferSize, file);
    fclose(file);
}

// Print the Bag of Words model
void printBagOfWords() {
    printf("Bag of Words Model:\n");
    for (int i = 0; i < HASH_SIZE; i++) {
        Node* current = hashTable[i];
        while (current) {
            printf("%s: %d\n", current->word, current->count);
            current = current->next;
        }
    }
}

// Free allocated memory
void freeMemory() {
    for (int i = 0; i < HASH_SIZE; i++) {
        Node* current = hashTable[i];
        while (current) {
            Node* temp = current;
            current = current->next;
            free(temp);
        }
    }
}

// Main function
int main() {
    char text[5000] = {0};  // Buffer to store input text

    // Read input from file (change "input.txt" as needed)
    readFile("input.txt", text, sizeof(text));

    // Process text and build BoW
    processText(text);

    // Display the Bag of Words model
    printBagOfWords();

    // Free allocated memory
    freeMemory();

    return 0;
}
