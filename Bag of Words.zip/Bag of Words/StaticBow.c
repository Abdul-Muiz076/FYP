#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <ctype.h>
#include "text_preprocessing.h"

#define MAX_WORDS 1000   // Maximum unique words
#define MAX_WORD_LEN 50  // Maximum word length

// Structure to store words and their frequency
typedef struct {
    char word[MAX_WORD_LEN];
    int count;
} WordFreq;

// Function to check if a word exists in the array
int findWord(WordFreq words[], int size, char *word) {
    for (int i = 0; i < size; i++) {
        if (strcmp(words[i].word, word) == 0) {
            return i;  // Return index if word exists
        }
    }
    return -1;  // Return -1 if word is new
}

// Function to add a word to the Bag of Words
void addWord(WordFreq words[], int *size, char *word) {
    int index = findWord(words, *size, word);
    if (index != -1) {
        words[index].count++;  // Increment count if word exists
    } else {
        strcpy(words[*size].word, word);
        words[*size].count = 1;
        (*size)++;
    }
}

// Function to tokenize input text and build the BoW
void processText(char *text, WordFreq words[], int *size) {
    removeHTMLTags(text);  // Remove HTML tags first
    removeURLs(text);      // Remove URLs
    removeAccents(text); 
    char *token = strtok(text, " ,.?!\n"); // Tokenize text
    while (token != NULL) {
        toLowerCase(token);
        removePunctuation(token);
        lemmatizeWord(token);
        if (!isStopWord(token) && isalpha(token[0]) && strlen(token) > 1) {  
            addWord(words, size, token);
        }
        token = strtok(NULL, " ,.?!\n");
    }
}
// Function to read text from a file
void readFile(char *filename, char *buffer, int bufferSize) {
    FILE *file = fopen(filename, "r");
    if (file == NULL) {
        printf("Error opening file.\n");
        exit(1);
    }
    fread(buffer, 1, bufferSize, file);
    fclose(file);
}

// Main function
int main() {
    char text[5000]; // Buffer to store input text
    WordFreq words[MAX_WORDS]; // Array to store word frequencies
    int size = 0; // Number of unique words

    // Read input from file (change "input.txt" as needed)
    readFile("input.txt", text, sizeof(text));

    // Process text and build BoW
    processText(text, words, &size);

    // Display Bag of Words (word-frequency pairs)
    printf("Bag of Words Model:\n");
    for (int i = 0; i < size; i++) {
        printf("%s: %d\n", words[i].word, words[i].count);
    }

    return 0;
}
