#pragma once

// Include necessary headers for C++/CLI and native code interaction
#include <string>
#include <vector>
#include "bow_logic.h" // Include your native logic header
#include <msclr/marshal_cppstd.h> // For string conversions

namespace BOWGUI { // Replace with your project's namespace

    using namespace System;
    using namespace System::ComponentModel;
    using namespace System::Collections;
    using namespace System::Windows::Forms;
    using namespace System::Data;
    using namespace System::Drawing;
    using namespace msclr::interop; // For marshal_as

    /// <summary>
    /// Summary for MyForm
    /// </summary>
    public ref class MyFormBOW : public System::Windows::Forms::Form
    {
    public:
        // Inside MyForm class, add a Load event handler or put in constructor AFTER InitializeComponent()

// Example: Add this method call in the constructor:
        MyFormBOW(void)
        {
            InitializeComponent();
            ApplyCustomStyles(); // Call the styling function
            // ... rest of constructor ...
            this->btnGenerate->Enabled = false;
            AddStatus("Ready. Please select an input text file.");
        }

        // New function to apply styles programmatically
    private: void ApplyCustomStyles()
    {
        // Form Style
        this->BackColor = System::Drawing::Color::WhiteSmoke; // Lighter background
        this->Font = gcnew System::Drawing::Font(L"Segoe UI", 9.0F, System::Drawing::FontStyle::Regular, System::Drawing::GraphicsUnit::Point, static_cast<System::Byte>(0));
        this->Padding = System::Windows::Forms::Padding(10); // Add padding around edges

        // Button Styles
        ApplyButtonStyle(btnBrowse);
        ApplyButtonStyle(btnGenerate);
        btnBrowse->Width = 30; // Make browse button smaller

        // DataGridView Styles
        ApplyDataGridViewStyle(dgvVocab);
        ApplyDataGridViewStyle(dgvVectors);

        // Specific adjustments if needed
        label2->Font = gcnew System::Drawing::Font(this->Font->FontFamily, this->Font->Size, FontStyle::Bold); // Bold Header
        label3->Font = gcnew System::Drawing::Font(this->Font->FontFamily, this->Font->Size, FontStyle::Bold); // Bold Header

        // Status Box Style
        txtStatus->BackColor = System::Drawing::Color::FromArgb(224, 224, 224); // Slightly different background
        txtStatus->BorderStyle = System::Windows::Forms::BorderStyle::FixedSingle;
    }

           // Helper for Button Styling
    private: void ApplyButtonStyle(Button^ btn)
    {
        btn->FlatStyle = System::Windows::Forms::FlatStyle::Flat;
        btn->FlatAppearance->BorderSize = 0;
        btn->BackColor = System::Drawing::Color::FromArgb(70, 130, 180); // SteelBlue
        btn->ForeColor = System::Drawing::Color::White;
        btn->FlatAppearance->MouseOverBackColor = System::Drawing::Color::FromArgb(100, 160, 210); // Lighter blue on hover
        btn->Font = gcnew System::Drawing::Font(this->Font->FontFamily, this->Font->Size, FontStyle::Bold);
    }

           // Helper for DataGridView Styling
    private: void ApplyDataGridViewStyle(DataGridView^ dgv)
    {
        dgv->BorderStyle = System::Windows::Forms::BorderStyle::None;
        dgv->BackgroundColor = System::Drawing::Color::FromArgb(235, 235, 245); // Light lavender/grey background
        dgv->GridColor = System::Drawing::Color::Gainsboro; // Light grid lines
        dgv->RowHeadersVisible = false;
        dgv->EnableHeadersVisualStyles = false; // IMPORTANT!

        // Column Header Style
        dgv->ColumnHeadersDefaultCellStyle->BackColor = System::Drawing::Color::FromArgb(64, 64, 96); // Dark Slate Blue/Grey
        dgv->ColumnHeadersDefaultCellStyle->ForeColor = System::Drawing::Color::White;
        dgv->ColumnHeadersDefaultCellStyle->Font = gcnew System::Drawing::Font(this->Font->FontFamily, 9.0F, System::Drawing::FontStyle::Bold);
        dgv->ColumnHeadersDefaultCellStyle->Alignment = DataGridViewContentAlignment::MiddleCenter;
        dgv->ColumnHeadersDefaultCellStyle->Padding = System::Windows::Forms::Padding(5); // Add padding to headers
        dgv->ColumnHeadersBorderStyle = DataGridViewHeaderBorderStyle::Single; // Add subtle border to headers

        // Default Cell Style (Non-Alternating Rows)
        dgv->DefaultCellStyle->BackColor = System::Drawing::Color::White;
        dgv->DefaultCellStyle->ForeColor = System::Drawing::Color::FromArgb(48, 48, 48); // Dark Grey Text
        dgv->DefaultCellStyle->SelectionBackColor = System::Drawing::Color::FromArgb(190, 210, 255); // Light Cornflower Blue selection
        dgv->DefaultCellStyle->SelectionForeColor = System::Drawing::Color::Black;
        dgv->DefaultCellStyle->Padding = System::Windows::Forms::Padding(3); // Padding within cells
        dgv->DefaultCellStyle->WrapMode = DataGridViewTriState::False; // Prevent text wrapping usually

        // Alternating Row Style (Zebra Stripes)
        dgv->AlternatingRowsDefaultCellStyle->BackColor = System::Drawing::Color::FromArgb(245, 245, 250); // Very light lavender white
        dgv->AlternatingRowsDefaultCellStyle->ForeColor = dgv->DefaultCellStyle->ForeColor;
        dgv->AlternatingRowsDefaultCellStyle->SelectionBackColor = dgv->DefaultCellStyle->SelectionBackColor;
        dgv->AlternatingRowsDefaultCellStyle->SelectionForeColor = dgv->DefaultCellStyle->SelectionForeColor;
    }

    protected:
        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        ~MyFormBOW()
        {
            if (components)
            {
                delete components;
            }
        }
    private: System::Windows::Forms::Label^ label1;
    private: System::Windows::Forms::TextBox^ txtFilePath;
    private: System::Windows::Forms::Button^ btnBrowse;
    private: System::Windows::Forms::Button^ btnGenerate;
    private: System::Windows::Forms::Label^ label2;
    private: System::Windows::Forms::DataGridView^ dgvVocab;
    private: System::Windows::Forms::Label^ label3;
    private: System::Windows::Forms::DataGridView^ dgvVectors;
    private: System::Windows::Forms::TextBox^ txtStatus;
    private: System::Windows::Forms::OpenFileDialog^ openFileDialog1;
    private: System::ComponentModel::IContainer^ components;


    private:
        /// <summary>
        /// Required designer variable.
        /// </summary>


#pragma region Windows Form Designer generated code
        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        void InitializeComponent(void)
        {
            this->label1 = (gcnew System::Windows::Forms::Label());
            this->txtFilePath = (gcnew System::Windows::Forms::TextBox());
            this->btnBrowse = (gcnew System::Windows::Forms::Button());
            this->btnGenerate = (gcnew System::Windows::Forms::Button());
            this->label2 = (gcnew System::Windows::Forms::Label());
            this->dgvVocab = (gcnew System::Windows::Forms::DataGridView());
            this->label3 = (gcnew System::Windows::Forms::Label());
            this->dgvVectors = (gcnew System::Windows::Forms::DataGridView());
            this->txtStatus = (gcnew System::Windows::Forms::TextBox());
            this->openFileDialog1 = (gcnew System::Windows::Forms::OpenFileDialog());
            (cli::safe_cast<System::ComponentModel::ISupportInitialize^>(this->dgvVocab))->BeginInit();
            (cli::safe_cast<System::ComponentModel::ISupportInitialize^>(this->dgvVectors))->BeginInit();
            this->SuspendLayout();
            //
            // label1
            //
            this->label1->AutoSize = true;
            this->label1->Location = System::Drawing::Point(12, 15);
            this->label1->Name = L"label1";
            this->label1->Size = System::Drawing::Size(57, 13);
            this->label1->TabIndex = 0;
            this->label1->Text = L"Input File:";
            //
            // txtFilePath
            //
            this->txtFilePath->Anchor = static_cast<System::Windows::Forms::AnchorStyles>(((System::Windows::Forms::AnchorStyles::Top | System::Windows::Forms::AnchorStyles::Left)
                | System::Windows::Forms::AnchorStyles::Right));
            this->txtFilePath->Location = System::Drawing::Point(75, 12);
            this->txtFilePath->Name = L"txtFilePath";
            this->txtFilePath->ReadOnly = true;
            this->txtFilePath->Size = System::Drawing::Size(530, 20);
            this->txtFilePath->TabIndex = 1;
            //
            // btnBrowse
            //
            this->btnBrowse->Anchor = static_cast<System::Windows::Forms::AnchorStyles>((System::Windows::Forms::AnchorStyles::Top | System::Windows::Forms::AnchorStyles::Right));
            this->btnBrowse->Location = System::Drawing::Point(611, 10);
            this->btnBrowse->Name = L"btnBrowse";
            this->btnBrowse->Size = System::Drawing::Size(35, 23);
            this->btnBrowse->TabIndex = 2;
            this->btnBrowse->Text = L"...";
            this->btnBrowse->UseVisualStyleBackColor = true;
            this->btnBrowse->Click += gcnew System::EventHandler(this, &MyFormBOW::btnBrowse_Click);
            //
            // btnGenerate
            //
            this->btnGenerate->Anchor = static_cast<System::Windows::Forms::AnchorStyles>((System::Windows::Forms::AnchorStyles::Top | System::Windows::Forms::AnchorStyles::Right));
            this->btnGenerate->Location = System::Drawing::Point(652, 10);
            this->btnGenerate->Name = L"btnGenerate";
            this->btnGenerate->Size = System::Drawing::Size(120, 23);
            this->btnGenerate->TabIndex = 3;
            this->btnGenerate->Text = L"Generate BoW";
            this->btnGenerate->UseVisualStyleBackColor = true;
            this->btnGenerate->Click += gcnew System::EventHandler(this, &MyFormBOW::btnGenerate_Click);
            //
            // label2
            //
            this->label2->AutoSize = true;
            this->label2->Location = System::Drawing::Point(12, 49);
            this->label2->Name = L"label2";
            this->label2->Size = System::Drawing::Size(131, 13);
            this->label2->TabIndex = 4;
            this->label2->Text = L"Vocabulary (BoW Model):";
            //
            // dgvVocab
            //
            this->dgvVocab->AllowUserToAddRows = false;
            this->dgvVocab->AllowUserToDeleteRows = false;
            this->dgvVocab->Anchor = static_cast<System::Windows::Forms::AnchorStyles>(((System::Windows::Forms::AnchorStyles::Top | System::Windows::Forms::AnchorStyles::Left)
                | System::Windows::Forms::AnchorStyles::Right));
            this->dgvVocab->AutoSizeColumnsMode = System::Windows::Forms::DataGridViewAutoSizeColumnsMode::Fill;
            this->dgvVocab->ColumnHeadersHeightSizeMode = System::Windows::Forms::DataGridViewColumnHeadersHeightSizeMode::AutoSize;
            this->dgvVocab->Location = System::Drawing::Point(15, 65);
            this->dgvVocab->Name = L"dgvVocab";
            this->dgvVocab->ReadOnly = true;
            this->dgvVocab->Size = System::Drawing::Size(757, 150);
            this->dgvVocab->TabIndex = 5;
            //
            // label3
            //
            this->label3->AutoSize = true;
            this->label3->Location = System::Drawing::Point(12, 230);
            this->label3->Name = L"label3";
            this->label3->Size = System::Drawing::Size(75, 13);
            this->label3->TabIndex = 6;
            this->label3->Text = L"BoW Vectors:";
            //
            // dgvVectors
            //
            this->dgvVectors->AllowUserToAddRows = false;
            this->dgvVectors->AllowUserToDeleteRows = false;
            this->dgvVectors->Anchor = static_cast<System::Windows::Forms::AnchorStyles>((((System::Windows::Forms::AnchorStyles::Top | System::Windows::Forms::AnchorStyles::Bottom)
                | System::Windows::Forms::AnchorStyles::Left)
                | System::Windows::Forms::AnchorStyles::Right));
            this->dgvVectors->AutoSizeColumnsMode = System::Windows::Forms::DataGridViewAutoSizeColumnsMode::DisplayedCells;
            this->dgvVectors->ColumnHeadersHeightSizeMode = System::Windows::Forms::DataGridViewColumnHeadersHeightSizeMode::AutoSize;
            this->dgvVectors->Location = System::Drawing::Point(15, 246);
            this->dgvVectors->Name = L"dgvVectors";
            this->dgvVectors->ReadOnly = true;
            this->dgvVectors->Size = System::Drawing::Size(757, 200); // Adjust height as needed
            this->dgvVectors->TabIndex = 7;
            //
            // txtStatus
            //
            this->txtStatus->Anchor = static_cast<System::Windows::Forms::AnchorStyles>(((System::Windows::Forms::AnchorStyles::Bottom | System::Windows::Forms::AnchorStyles::Left)
                | System::Windows::Forms::AnchorStyles::Right));
            this->txtStatus->Location = System::Drawing::Point(15, 452); // Adjust Y position
            this->txtStatus->Multiline = true;
            this->txtStatus->Name = L"txtStatus";
            this->txtStatus->ReadOnly = true;
            this->txtStatus->ScrollBars = System::Windows::Forms::ScrollBars::Vertical;
            this->txtStatus->Size = System::Drawing::Size(757, 60); // Adjust height
            this->txtStatus->TabIndex = 8;
            //
            // openFileDialog1
            //
            this->openFileDialog1->Filter = L"Text files (*.txt)|*.txt|All files (*.*)|*.*";
            this->openFileDialog1->Title = L"Select Input Text File";
            //
            // MyForm
            //
            this->AutoScaleDimensions = System::Drawing::SizeF(6, 13);
            this->AutoScaleMode = System::Windows::Forms::AutoScaleMode::Font;
            this->ClientSize = System::Drawing::Size(784, 524); // Adjust size
            this->Controls->Add(this->txtStatus);
            this->Controls->Add(this->dgvVectors);
            this->Controls->Add(this->label3);
            this->Controls->Add(this->dgvVocab);
            this->Controls->Add(this->label2);
            this->Controls->Add(this->btnGenerate);
            this->Controls->Add(this->btnBrowse);
            this->Controls->Add(this->txtFilePath);
            this->Controls->Add(this->label1);
            this->Name = L"MyForm";
            this->Text = L"Bag of Words Generator GUI";
            (cli::safe_cast<System::ComponentModel::ISupportInitialize^>(this->dgvVocab))->EndInit();
            (cli::safe_cast<System::ComponentModel::ISupportInitialize^>(this->dgvVectors))->EndInit();
            this->ResumeLayout(false);
            this->PerformLayout();

        }
#pragma endregion

        // --- Helper function to add messages to the status box ---
    private: void AddStatus(String^ message) {
        if (txtStatus->Text->Length > 0) {
            txtStatus->AppendText("\r\n"); // New line
        }
        txtStatus->AppendText(DateTime::Now.ToString("HH:mm:ss") + ": " + message);
        txtStatus->ScrollToCaret(); // Scroll to the bottom
    }

           // --- Event Handlers ---
    private: System::Void btnBrowse_Click(System::Object^ sender, System::EventArgs^ e) {
        if (openFileDialog1->ShowDialog() == System::Windows::Forms::DialogResult::OK) {
            this->txtFilePath->Text = openFileDialog1->FileName;
            this->btnGenerate->Enabled = true; // Enable Generate button
            AddStatus("Selected file: " + openFileDialog1->FileName);
        }
    }

    private: System::Void btnGenerate_Click(System::Object^ sender, System::EventArgs^ e) {
        if (String::IsNullOrWhiteSpace(this->txtFilePath->Text)) {
            MessageBox::Show("Please select an input file first.", "Error", MessageBoxButtons::OK, MessageBoxIcon::Warning);
            return;
        }

        // Disable button during processing
        this->btnGenerate->Enabled = false;
        this->btnBrowse->Enabled = false;
        this->Cursor = Cursors::WaitCursor; // Show wait cursor

        // Clear previous results
        dgvVocab->Rows->Clear();
        dgvVocab->Columns->Clear();
        dgvVectors->Rows->Clear();
        dgvVectors->Columns->Clear();
        AddStatus("Processing file: " + this->txtFilePath->Text + "...");
        Application::DoEvents(); // Allow UI to update

        // Convert managed filename string to native std::string
        std::string nativeFilename = marshal_as<std::string>(this->txtFilePath->Text);
        std::vector<Word> vocabData;
        std::vector<std::vector<int>> vectorData;
        std::string errorMessage;

        // --- Call the native C++ processing function ---
        bool success = generateBoW(nativeFilename, vocabData, vectorData, errorMessage);
        // ---------------------------------------------

        if (success) {
            AddStatus("Processing complete. Populating tables...");
            Application::DoEvents();

            // --- Populate Vocabulary DataGridView ---
            dgvVocab->Columns->Add("WordCol", "Word");
            dgvVocab->Columns->Add("FreqCol", "Frequency");
            dgvVocab->Columns["FreqCol"]->DefaultCellStyle->Alignment = DataGridViewContentAlignment::MiddleRight;

            for (const auto& wordEntry : vocabData) {
                String^ managedWord = marshal_as<String^>(wordEntry.word);
                dgvVocab->Rows->Add(managedWord, wordEntry.frequency.ToString());
            }
            AddStatus("Vocabulary table populated.");
            Application::DoEvents();


            // --- Populate Vectors DataGridView ---
            if (!vocabData.empty()) {
                // Add columns based on vocabulary
                dgvVectors->Columns->Add("SentenceCol", "Sentence #"); // Add sentence number column
                dgvVectors->Columns["SentenceCol"]->DefaultCellStyle->Alignment = DataGridViewContentAlignment::MiddleCenter;
                dgvVectors->Columns["SentenceCol"]->Width = 60; // Adjust width

                for (const auto& wordEntry : vocabData) {
                    String^ managedWord = marshal_as<String^>(wordEntry.word);
                    dgvVectors->Columns->Add("Vocab_" + managedWord, managedWord); // Use unique names
                    dgvVectors->Columns["Vocab_" + managedWord]->DefaultCellStyle->Alignment = DataGridViewContentAlignment::MiddleCenter;
                    dgvVectors->Columns["Vocab_" + managedWord]->Width = 40; // Adjust width
                }

                // Add rows for each sentence vector
                for (size_t i = 0; i < vectorData.size(); ++i) {
                    DataGridViewRow^ newRow = gcnew DataGridViewRow();
                    newRow->CreateCells(dgvVectors); // Important! Create cells based on current columns

                    // Set Sentence number first
                    newRow->Cells[0]->Value = (i + 1).ToString();

                    // Populate vector values (starting from the second column)
                    const auto& vec = vectorData[i];
                    for (size_t j = 0; j < vocabData.size(); ++j) {
                        // Check bounds just in case, though resize should prevent this
                        int value = (j < vec.size()) ? vec[j] : 0;
                        // Offset column index by 1 because of the "Sentence #" column
                        newRow->Cells[j + 1]->Value = value.ToString();
                    }
                    dgvVectors->Rows->Add(newRow);
                }
                AddStatus("BoW Vectors table populated.");
                Application::DoEvents();
            }
            else {
                AddStatus("Vocabulary is empty, cannot populate vectors table.");
            }


            AddStatus("BoW Model saved to bow_model.csv");
            AddStatus("BoW Vectors saved to bow_vectors.csv");
            AddStatus("Finished successfully.");

        }
        else {
            // Show error message from the native function
            String^ managedError = marshal_as<String^>(errorMessage);
            MessageBox::Show("An error occurred during processing:\n" + managedError, "Processing Error", MessageBoxButtons::OK, MessageBoxIcon::Error);
            AddStatus("Processing failed: " + managedError);
        }

        // Re-enable controls and reset cursor
        this->Cursor = Cursors::Default;
        this->btnGenerate->Enabled = true;
        this->btnBrowse->Enabled = true;
    } // End btnGenerate_Click

    }; // End class MyForm
} // End namespace BoW_GUI